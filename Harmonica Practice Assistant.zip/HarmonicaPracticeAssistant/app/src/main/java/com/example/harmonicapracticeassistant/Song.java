package com.example.harmonicapracticeassistant;

import java.util.List;

public class Song
{
    String name;
    String tabs;
    boolean isMainRecording;
    List<String> recordings;
}

package com.example.harmonicapracticeassistant;

import android.content.Context;

import java.util.List;

import androidx.recyclerview.widget.RecyclerView;

public class SongListAdapter //extends RecyclerView.Adapter<PlaylistAdapter.ViewHolder> implements ItemTouchHelperAdapter
{
    private Context context;
    private List<Song> songs;
}

package com.example.harmonicapracticeassistant;

public class Keys
{
    final static String IS_NEW_SONG = "IS_NEW_SONG";
}
